const User = require("../modelos/user.modelos");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { TOKEN_SECRET } = require("../config");
const { crearTokenAcceso } = require("../libs/jwt");

/* Crear nuevo usuario con nombre de usuario email y constraseña */

async function registro(req, res) {
  try {
    const { usuario, email, password } = req.body;

    const usuarioEncontrado = await User.findOne({ email });
    if (usuarioEncontrado)
      return res.status(400).json({ mensaje: ["El correo ya está en uso"] });

    const passwordHash = await bcrypt.hash(password, 10);

    const nuevoUsuario = new User({ usuario, email, password: passwordHash });
    const guardarUsuario = await nuevoUsuario.save();

    const token = await crearTokenAcceso({ id: guardarUsuario._id });

    res.cookie("token", token, {
      httpOnly: process.env.NODE_ENV !== "development",
      secure: true,
      sameSite: "none",
    });

    res.json({
      id: guardarUsuario._id,
      usuario: guardarUsuario.usuario,
      email: guardarUsuario.email,
      token,
    });
  } catch (error) {
    res.status(500).json({ mensaje: error.mensaje });
  }
}

/* Login en la aplicación */

async function login(req, res) {
  try {
    const { email, password } = req.body;
    const usuarioEncontrado = await User.findOne({ email });

    if (!usuarioEncontrado)
      return res.status(400).json({ mensaje: ["El correo no existe"] });

    const isMatch = await bcrypt.compare(password, usuarioEncontrado.password);
    if (!isMatch)
      return res.status(400).json({ mensaje: ["La contraseña es incorrecta"] });

    const token = await crearTokenAcceso({ id: usuarioEncontrado._id });

    res.cookie("token", token, {
      httpOnly: process.env.NODE_ENV !== "development",
      secure: true,
      sameSite: "none",
    });

    res.json({
      id: usuarioEncontrado._id,
      usuario: usuarioEncontrado.usuario,
      email: usuarioEncontrado.email,
    });
  } catch (error) {
    return res.status(500).json({ mensaje: error.mensaje });
  }
}

/* Verificacion de usuario pasandole el token */

async function verificarTokenUsuario(req, res) {
  const { token } = req.cookies;
  if (!token) return res.send(false);

  jwt.verify(token, TOKEN_SECRET, async (error, user) => {
    if (error) return res.sendStatus(401);

    const usuarioEncontrado = await User.findById(user.id);
    if (!usuarioEncontrado) return res.sendStatus(401);

    return res.json({
      id: usuarioEncontrado._id,
      usuario: usuarioEncontrado.usuario,
      email: usuarioEncontrado.email,
    });
  });
}

module.exports = {
  registro,
  login,
  verificarTokenUsuario,
};
