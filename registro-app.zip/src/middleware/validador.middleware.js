/**
 * Middleware para validar la estructura del cuerpo de la petición
 * utilizando esquemas de Zod
 */
function validateSchema(schema) {
  return (req, res, next) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      return res.status(400).json({
        mensaje: error.errors.map((err) => err.mensaje),
      });
    }
  };
}

module.exports = { validateSchema };
