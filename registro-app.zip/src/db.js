const mongoose = require("mongoose");
const { MONGODB_URI } = require("./config");

async function connectDB() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log("MongoDB conectado exitosamente");
  } catch (error) {
    console.error("Error conectando a MongoDB:", error);
  }
}

module.exports = { connectDB };
